CREATE DATABASE IF NOT EXISTS merchandisedb;
USE merchandisedb;

-- Users table
CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    phone VARCHAR(20),
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    usertype ENUM('Admin', 'SalesStaff', 'SalesOperationsStaff', 'Customer') NOT NULL
);

-- Users table Records
INSERT INTO Users (name, location, phone, username, password, usertype)
VALUES
    ('User1', 'local', '1234567890', 'admin', 'admin', 'Admin'),
    ('User2', 'Nairobi', '9876543210', 'user1', 'user1', 'SalesOperationsStaff'),
    ('User4', 'Mombasa', '9876543210', 'staff', 'staff', 'SalesStaff'),
    ('User5', 'Kisumu', '9876543210', 'customer', 'customer', 'Customer');


-- SalesStaff table
CREATE TABLE IF NOT EXISTS SalesStaff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    staff_number VARCHAR(20) NOT NULL,
    employment_type ENUM('Permanent', 'Contract') NOT NULL,
    region VARCHAR(50),
    enterprise_size ENUM('Small', 'Medium', 'Large') NOT NULL,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- SalesStaff table records
INSERT INTO SalesStaff (name, staff_number, employment_type, region, enterprise_size, user_id)
VALUES
    ('John Doe', 'S12345', 'Permanent', 'North', 'Medium', 1),
    ('Jane Smith', 'S67890', 'Contract', 'South', 'Small', 2);

-- Merchandise table
CREATE TABLE IF NOT EXISTS Merchandise (
    merchandise_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    stock_number VARCHAR(20) NOT NULL,
    batch_number VARCHAR(20),
    merchandise_type VARCHAR(50) NOT NULL,
    campaign_id INT,
    sales_incentive BOOLEAN
);

-- Merchandise table Records
INSERT INTO Merchandise (name, stock_number, batch_number, merchandise_type, campaign_id, sales_incentive)
VALUES
    ('Pen', 'P001', 'B001', 'Stationery', NULL, 1),
    ('T-shirt', 'T002', 'B002', 'Apparel', NULL, 0);

-- SalesOperationsStaff table
CREATE TABLE IF NOT EXISTS SalesOperationsStaff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    staff_number VARCHAR(20) NOT NULL,
    order_creator BOOLEAN,
    order_approver BOOLEAN,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- SalesOperationsStaff table Records
INSERT INTO SalesOperationsStaff (name, staff_number, order_creator, order_approver, user_id)
VALUES
    ('Mark Johnson', 'SO456', 1, 1, 3),
    ('Emily Davis', 'SO789', 1, 0, 4);

-- Create the Customers table
CREATE TABLE IF NOT EXISTS Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    customer_number VARCHAR(20) NOT NULL,
    region VARCHAR(50) NOT NULL,
    enterprise_type ENUM('Micro', 'Small', 'Medium', 'Large') NOT NULL,
    support_request BOOLEAN,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);



-- Insert two sample records into the Customers table
INSERT INTO Customers (name, customer_number, region, enterprise_type, support_request, user_id)
VALUES
    ('ABC Inc.', 'C001', 'West', 'Medium', 1, 5),
    ('XYZ Ltd.', 'C002', 'East', 'Large', 0, 6);

-- Create the Suppliers table
CREATE TABLE IF NOT EXISTS Suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    supplier_number VARCHAR(20) NOT NULL,
    items_produced VARCHAR(255) NOT NULL,
    items_supplied INT NOT NULL,
    product_price DECIMAL(10, 2) NOT NULL
);

-- Insert two sample records into the Suppliers table
INSERT INTO Suppliers (name, supplier_number, items_produced, items_supplied, product_price)
VALUES
    ('Supplier1', 'SUP001', 'Paper', 1000, 2.50),
    ('Supplier2', 'SUP002', 'Fabric', 500, 5.75);

-- Create the Orders table
CREATE TABLE IF NOT EXISTS Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_date DATE NOT NULL,
    sales_staff_id INT NOT NULL,
    supplier_id INT NOT NULL,
    merchandise_name VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    artwork_and_samples TEXT,
    status ENUM('Pending', 'Approved', 'Rejected') NOT NULL
);

INSERT INTO Orders (order_date, sales_staff_id, supplier_id, merchandise_name, quantity, artwork_and_samples, status)
VALUES
    ('2019-09-01', 1, 1, 'Pen', 500, 'Sample artwork attached.', 'Approved');
    ('2019-09-02', 2, 2, 'T-shirt', 200, 'No artwork provided.', 'Pending');
