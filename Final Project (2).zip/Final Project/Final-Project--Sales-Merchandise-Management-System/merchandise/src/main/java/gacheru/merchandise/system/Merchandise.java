/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Admin
 */
public class Merchandise {
    private int merchandiseId;
    private String name;
    private String stockNumber;
    private String batchNumber;
    private String merchandiseType;
    private int campaignId;
    private boolean salesIncentive;

    public Merchandise() {
        // Initialize attributes
    }
    
    public void setMerchandiseId(int merchandiseId) {
        this.merchandiseId = merchandiseId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStockNumber(String stockNumber) {
        this.stockNumber = stockNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public void setMerchandiseType(String merchandiseType) {
        this.merchandiseType = merchandiseType;
    }

    public void setCampaignId(int campaignId) {
        this.campaignId = campaignId;
    }

    public void setSalesIncentive(boolean salesIncentive) {
        this.salesIncentive = salesIncentive;
    }

    // Getter methods
    public int getMerchandiseId() {
        return merchandiseId;
    }

    public String getName() {
        return name;
    }

    public String getStockNumber() {
        return stockNumber;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public String getMerchandiseType() {
        return merchandiseType;
    }

    public int getCampaignId() {
        return campaignId;
    }

    public boolean isSalesIncentive() {
        return salesIncentive;
    }
    
    public static List<Merchandise> getAllMerchandise() {
        List<Merchandise> merchandiseList = new ArrayList<>();
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "SELECT * FROM Merchandise";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Merchandise merchandise = new Merchandise();
                merchandise.setMerchandiseId(resultSet.getInt("merchandise_id"));
                merchandise.setName(resultSet.getString("name"));
                merchandise.setStockNumber(resultSet.getString("stock_number"));
                merchandise.setBatchNumber(resultSet.getString("batch_number"));
                merchandise.setMerchandiseType(resultSet.getString("merchandise_type"));
                merchandise.setCampaignId(resultSet.getInt("campaign_id"));
                merchandise.setSalesIncentive(resultSet.getBoolean("sales_incentive"));
                merchandiseList.add(merchandise);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error retrieving Merchandise records: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
        return merchandiseList;
    }


    public void addMerchandise() {
        Connection connection;
        connection = DatabaseConnector.connect();
        try {
            String sql = "INSERT INTO Merchandise (name, stock_number, batch_number, merchandise_type, campaign_id, sales_incentive) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, this.name);
            preparedStatement.setString(2, this.stockNumber);
            preparedStatement.setString(3, this.batchNumber);
            preparedStatement.setString(4, this.merchandiseType);
            preparedStatement.setInt(5, this.campaignId);
            preparedStatement.setBoolean(6, this.salesIncentive);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error adding merchandise: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    
}