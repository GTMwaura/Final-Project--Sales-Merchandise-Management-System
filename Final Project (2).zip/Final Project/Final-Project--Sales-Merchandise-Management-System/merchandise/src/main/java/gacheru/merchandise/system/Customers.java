/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Admin
 */
public class Customers {
    public int customerId;
    private String name;
    private String customerNumber;
    private String region;
    private String enterpriseType;
    private boolean supportRequest;

    public Customers() {};
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setEnterpriseType(String enterpriseType) {
        this.enterpriseType = enterpriseType;
    }

    public void setSupportRequest(boolean supportRequest) {
        this.supportRequest = supportRequest;
    }
    
    public int getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public String getRegion() {
        return region;
    }

    public String getEnterpriseType() {
        return enterpriseType;
    }

    public boolean isSupportRequest() {
        return supportRequest;
    }
    
    public static List<Customers> getAllCustomers() {
    List<Customers> customerList = new ArrayList<>();
    Connection connection = DatabaseConnector.connect();
    try {
        String sql = "SELECT * FROM Customers";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            Customers customer = new Customers();
            customer.setCustomerId(resultSet.getInt("customer_id"));
            customer.setName(resultSet.getString("name"));
            customer.setCustomerNumber(resultSet.getString("customer_number"));
            customer.setRegion(resultSet.getString("region"));
            customer.setEnterpriseType(resultSet.getString("enterprise_type"));
            customer.setSupportRequest(resultSet.getBoolean("support_request"));
            customerList.add(customer);
        }
        //resultSet.close();
        //preparedStatement.close();
    } catch (SQLException e) {
        System.err.println("Error retrieving Customers: " + e.getMessage());
    } finally {
        DatabaseConnector.close(connection);
    }
    return customerList;
}



    public void purchaseCompanySolutions(int orderId) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "UPDATE Orders SET status = 'Completed' WHERE order_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error completing order: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    public void requestSupport() {
        // Implement logic for a customer to request support
    }

}