/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;
/**
 *
 * @author Admin
 */
public class SalesStaff {
    private int staffId;
    private String name;
    private String staffNumber;
    private String employmentType;
    private String region;
    private String enterpriseSize;

    public SalesStaff() {
        // Initialize attributes
    }
    
    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    // Getter and Setter methods for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter methods for staffNumber
    public String getStaffNumber() {
        return staffNumber;
    }

    public void setStaffNumber(String staffNumber) {
        this.staffNumber = staffNumber;
    }

    // Getter and Setter methods for employmentType
    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    // Getter and Setter methods for region
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    // Getter and Setter methods for enterpriseSize
    public String getEnterpriseSize() {
        return enterpriseSize;
    }

    public void setEnterpriseSize(String enterpriseSize) {
        this.enterpriseSize = enterpriseSize;
    }

    
     public void createSalesStaff() {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "INSERT INTO SalesStaff (name, staff_number, employment_type, region, enterprise_size) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, this.name);
            preparedStatement.setString(2, this.staffNumber);
            preparedStatement.setString(3, this.employmentType);
            preparedStatement.setString(4, this.region);
            preparedStatement.setString(5, this.enterpriseSize);
            preparedStatement.executeUpdate();
            preparedStatement.close();
            System.out.println("Sales Staff member created successfully.");
        } catch (SQLException e) {
            System.err.println("Error creating Sales Staff member: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    // Read all Sales Staff members from the database
    public static List<SalesStaff> getAllSalesStaff() {
        List<SalesStaff> salesStaffList = new ArrayList<>();
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "SELECT * FROM SalesStaff";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                SalesStaff salesStaff = new SalesStaff();
                salesStaff.setStaffId(resultSet.getInt("staff_id"));
                salesStaff.setName(resultSet.getString("name"));
                salesStaff.setStaffNumber(resultSet.getString("staff_number"));
                salesStaff.setEmploymentType(resultSet.getString("employment_type"));
                salesStaff.setRegion(resultSet.getString("region"));
                salesStaff.setEnterpriseSize(resultSet.getString("enterprise_size"));
                salesStaffList.add(salesStaff);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error retrieving Sales Staff members: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
        return salesStaffList;
    }

    // Update a Sales Staff member
    public void updateSalesStaff() {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "UPDATE SalesStaff SET name=?, employment_type=?, region=?, enterprise_size=? WHERE staff_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, this.name);
            preparedStatement.setString(2, this.employmentType);
            preparedStatement.setString(3, this.region);
            preparedStatement.setString(4, this.enterpriseSize);
            preparedStatement.setInt(5, this.staffId);
            int rowsUpdated = preparedStatement.executeUpdate();
            preparedStatement.close();
            if (rowsUpdated > 0) {
                System.out.println("Sales Staff member updated successfully.");
            } else {
                System.out.println("No Sales Staff member found with the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating Sales Staff member: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    // Delete a Sales Staff member by ID
    public static void deleteSalesStaff(int staffId) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "DELETE FROM SalesStaff WHERE staff_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, staffId);
            int rowsDeleted = preparedStatement.executeUpdate();
            preparedStatement.close();
            if (rowsDeleted > 0) {
                System.out.println("Sales Staff member deleted successfully.");
            } else {
                System.out.println("No Sales Staff member found with the given ID.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting Sales Staff member: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }
    
    
    public void orderMerchandise(int merchandiseId, int quantity) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "INSERT INTO Orders (order_date, sales_staff_id, merchandise_id, quantity, status) VALUES (CURDATE(), ?, ?, ?, 'Pending')";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, this.staffId);
            preparedStatement.setInt(2, merchandiseId);
            preparedStatement.setInt(3, quantity);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error ordering merchandise: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    // Other methods for SalesStaff
}
