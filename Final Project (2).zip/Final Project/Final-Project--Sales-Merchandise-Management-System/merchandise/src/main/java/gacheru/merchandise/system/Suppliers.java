/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Admin
 */
public class Suppliers {
    private int supplierId;
    private String name;
    private String supplierNumber;
    private String itemsProduced;
    private int itemsSupplied;
    private double productPrice;

    public Suppliers() {
        // Initialize attributes
    }
    
    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSupplierNumber() {
        return supplierNumber;
    }

    public void setSupplierNumber(String supplierNumber) {
        this.supplierNumber = supplierNumber;
    }

    public String getItemsProduced() {
        return itemsProduced;
    }

    public void setItemsProduced(String itemsProduced) {
        this.itemsProduced = itemsProduced;
    }

    public int getItemsSupplied() {
        return itemsSupplied;
    }

    public void setItemsSupplied(int itemsSupplied) {
        this.itemsSupplied = itemsSupplied;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public static List<Suppliers> getAllSuppliers() {
        List<Suppliers> supplierList = new ArrayList<>();
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "SELECT * FROM Suppliers";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Suppliers supplier = new Suppliers();
                supplier.setSupplierId(resultSet.getInt("supplier_id"));
                supplier.setName(resultSet.getString("name"));
                supplier.setSupplierNumber(resultSet.getString("supplier_number"));
                supplier.setItemsProduced(resultSet.getString("items_produced"));
                supplier.setItemsSupplied(resultSet.getInt("items_supplied"));
                supplier.setProductPrice(resultSet.getDouble("product_price"));
                supplierList.add(supplier);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error retrieving Suppliers: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
        return supplierList;
    }


    public void receiveOrder(int orderId) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "UPDATE Orders SET status = 'Received' WHERE order_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error receiving order: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    public void confirmOrder(int orderId) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "UPDATE Orders SET status = 'Confirmed' WHERE order_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error confirming order: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    // Other methods for Suppliers
}
