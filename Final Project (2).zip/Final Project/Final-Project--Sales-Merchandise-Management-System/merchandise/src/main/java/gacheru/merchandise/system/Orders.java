/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Admin
 */
public class Orders {
    
    private int orderId;
    private String orderDate;
    private String merchandiseName;
    private int salesStaffId;
    private int supplierId;
    private int quantity;
    private String artworkAndSamples;
    private String status;

    public Orders() {};
    
    public void setSalesStaffId(int salesStaffId) {
        this.salesStaffId = salesStaffId;
    }

    // Getter method for salesStaffId
    public int getSalesStaffId() {
        return salesStaffId;
    }

    // Setter method for supplierId
    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    // Getter method for supplierId
    public int getSupplierId() {
        return supplierId;
    }
    
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    // Getter and setter methods for orderDate
    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    // Getter and setter methods for merchandiseId
    public String getMerchandiseName() {
        return merchandiseName;
    }

    public void setMerchandiseName(String merchandiseId) {
        this.merchandiseName = merchandiseName;
    }

    // Getter and setter methods for quantity
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Getter and setter methods for artworkAndSamples
    public String getArtworkAndSamples() {
        return artworkAndSamples;
    }

    public void setArtworkAndSamples(String artworkAndSamples) {
        this.artworkAndSamples = artworkAndSamples;
    }

    // Getter and setter methods for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
 
    
    public static List<Orders> listOrders() {
    List<Orders> orderList = new ArrayList<>();
    Connection connection = DatabaseConnector.connect();
    try {
        String sql = "SELECT * FROM Orders";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            Orders order = new Orders();
            order.setOrderId(resultSet.getInt("order_id"));
            order.setOrderDate(resultSet.getString("order_date"));
            order.setSalesStaffId(resultSet.getInt("sales_staff_id"));
            order.setSupplierId(resultSet.getInt("supplier_id"));
            order.setMerchandiseName(resultSet.getString("merchandise_name"));
            order.setQuantity(resultSet.getInt("quantity"));
            order.setArtworkAndSamples(resultSet.getString("artwork_and_samples"));
            order.setStatus(resultSet.getString("status"));
            orderList.add(order);
        }
        resultSet.close();
        preparedStatement.close();
    } catch (SQLException e) {
        System.err.println("Error listing orders: " + e.getMessage());
    } finally {
        DatabaseConnector.close(connection);
    }
    return orderList;
}
    }
    
    
    
    
