/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.Database;
import java.sql.*;
/**
 *
 * @author Admin
 */
public class DatabaseConnector {
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;
    
    
    public DatabaseConnector(){
    
    };
    /**
    public void Connector(){
        //Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            statement = connection.createStatement();
            System.out.println("Connected to the database.");
        } catch (ClassNotFoundException e) {
            
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
        }
        
    }
    *
    * **/
    public static Connection connect() {
       Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/merchandisedb", "root","root");
            //System.out.println("Connected to the database.");
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
        }
        return connection;
    }
    
    public boolean checkLogin(String username, String password, String userType){
        String query = "SELECT * FROM users WHERE username='"
                + username
                + "' AND password='"
                + password
                + "' AND usertype='"
                + userType
                + "' LIMIT 1";

        try {
            resultSet = statement.executeQuery(query);
            if(resultSet.next()) return true;
        } catch (SQLException ex) {
        }
        return false;
        
    }
    
    // Inside the DatabaseConnector class

public static boolean addCustomer(String name, String customerNumber, String region, String enterpriseType, boolean supportRequest) {
    Connection connection = connect();
    try {
        String sql = "INSERT INTO Customers (name, customer_number, region, enterprise_type, support_request) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.setString(2, customerNumber);
        preparedStatement.setString(3, region);
        preparedStatement.setString(4, enterpriseType);
        preparedStatement.setBoolean(5, supportRequest);

        int rowsAffected = preparedStatement.executeUpdate();
        preparedStatement.close();

        if (rowsAffected > 0) {
            System.out.println("Customer added successfully.");
            return true; // Insertion successful
        } else {
            System.out.println("Failed to add customer.");
            return false; // Insertion failed
        }
    } catch (SQLException e) {
        System.err.println("Error adding customer: " + e.getMessage());
        return false; // Error occurred during insertion
    } finally {
        close(connection);
    }
}
    
    // Inside the DatabaseConnector class

public static boolean deleteCustomer(int customerId) {
    Connection connection = connect();
    try {
        String sql = "DELETE FROM Customers WHERE customer_id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, customerId);

        int rowsAffected = preparedStatement.executeUpdate();
        preparedStatement.close();

        if (rowsAffected > 0) {
            System.out.println("Customer with ID " + customerId + " has been deleted.");
            return true; // Deletion successful
        } else {
            System.out.println("Customer with ID " + customerId + " not found.");
            return false; // Customer not found
        }
    } catch (SQLException e) {
        System.err.println("Error deleting customer: " + e.getMessage());
        return false; // Error occurred during deletion
    } finally {
        close(connection);
    }
}

   
    public static boolean addMerchandise(String name, String stockNumber, String batchNumber, String merchandiseType, int campaignId, boolean salesIncentive) {
    Connection connection = connect();
    try {
        String sql = "INSERT INTO Merchandise (name, stock_number, batch_number, merchandise_type, campaign_id, sales_incentive) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, name);
        preparedStatement.setString(2, stockNumber);
        preparedStatement.setString(3, batchNumber);
        preparedStatement.setString(4, merchandiseType);
        preparedStatement.setInt(5, campaignId);
        preparedStatement.setBoolean(6, salesIncentive);

        int rowsAffected = preparedStatement.executeUpdate();
        preparedStatement.close();

        if (rowsAffected > 0) {
            System.out.println("Merchandise added successfully.");
            return true; // Insertion successful
        } else {
            System.out.println("Failed to add merchandise.");
            return false; // Insertion failed
        }
    } catch (SQLException e) {
        System.err.println("Error adding merchandise: " + e.getMessage());
        return false; // Error occurred during insertion
    } finally {
        close(connection);
    }
}

    
   public static boolean deleteMerchandise(int merchandiseIdToDelete) {
    Connection connection = connect();
    try {
        String sql = "DELETE FROM Merchandise WHERE merchandise_id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, merchandiseIdToDelete);

        int rowsAffected = preparedStatement.executeUpdate();
        preparedStatement.close();

        if (rowsAffected > 0) {
            System.out.println("Merchandise deleted successfully.");
            return true; // Deletion successful
        } else {
            System.out.println("Failed to delete merchandise. Merchandise ID not found.");
            return false; // Deletion failed, no matching merchandise ID found
        }
    } catch (SQLException e) {
        System.err.println("Error deleting merchandise: " + e.getMessage());
        return false; // Error occurred during deletion
    } finally {
        close(connection);
    }
}

    
   
    
   
    public static void close(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                System.err.println("Error closing database connection: " + e.getMessage());
            }
        }
    }
    
   
}
