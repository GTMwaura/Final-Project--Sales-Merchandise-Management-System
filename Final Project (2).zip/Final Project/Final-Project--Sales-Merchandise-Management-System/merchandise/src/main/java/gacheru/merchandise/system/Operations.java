/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gacheru.merchandise.system;
import gacheru.merchandise.Database.DatabaseConnector;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Admin
 */
public class Operations {
    private int staffId;
    private String name;
    private String staffNumber;
    private boolean orderCreator;
    private boolean orderApprover;

    public Operations() {
        // Initialize attributes
    }
    
    public static List<Operations> getAllSalesOperationsStaff() {
    List<Operations> salesOpsStaffList = new ArrayList<>();
    Connection connection = DatabaseConnector.connect();
    try {
        String sql = "SELECT * FROM SalesOperationsStaff";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            Operations salesOpsStaff = new Operations();
            salesOpsStaff.staffId = resultSet.getInt("staff_id");
            salesOpsStaff.name = resultSet.getString("name");
            salesOpsStaff.staffNumber = resultSet.getString("staff_number");
            salesOpsStaff.orderCreator = resultSet.getBoolean("order_creator");
            salesOpsStaff.orderApprover = resultSet.getBoolean("order_approver");
            salesOpsStaffList.add(salesOpsStaff);
        }
        resultSet.close();
        preparedStatement.close();
    } catch (SQLException e) {
        System.err.println("Error retrieving Sales Operations Staff members: " + e.getMessage());
    } finally {
        DatabaseConnector.close(connection);
    }
    return salesOpsStaffList;
}


    public void createOrder(int supplierId, int merchandiseId, int quantity) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "INSERT INTO Orders (order_date, sales_staff_id, supplier_id, merchandise_id, quantity, status) VALUES (CURDATE(), ?, ?, ?, ?, 'Pending')";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, this.staffId);
            preparedStatement.setInt(2, supplierId);
            preparedStatement.setInt(3, merchandiseId);
            preparedStatement.setInt(4, quantity);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error creating order: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    public void approveOrder(int orderId) {
        Connection connection = DatabaseConnector.connect();
        try {
            String sql = "UPDATE Orders SET status = 'Approved' WHERE order_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderId);
            preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            System.err.println("Error approving order: " + e.getMessage());
        } finally {
            DatabaseConnector.close(connection);
        }
    }

    
}
